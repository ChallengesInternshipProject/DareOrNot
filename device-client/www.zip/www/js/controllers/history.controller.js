angular.module('starter.controllers')

.controller('HistoryCtrl', function($scope, $http, $log, $localStorage) {
  $scope.history = {}; //Get history from db
  
  
});
