angular.module('starter.controllers')
  .controller('TestCtrl', function($scope, $stateParams, $localStorage, $http, $log, DareService) {

    DareService.get($stateParams.dareID).then(function(result) {
      $log.info(result);
    });
    DareService.list({
      title: {
        $ne: null
      },
      description: {
        $ne: null
      },
      endDate: {
        $gt: new Date()
      },
      _creator: $localStorage.user.data._id,
    }, false)
    .then(function(result) {
      $localStorage.dares = result[0];
      $log.info(result);
    });




    $scope.test = function() {
      return true;

    };

  });
