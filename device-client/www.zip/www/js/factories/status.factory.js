angular.module('starter')
  .factory('StatusFactory', function () {
    return {
      isLogged: false
    }
  });
