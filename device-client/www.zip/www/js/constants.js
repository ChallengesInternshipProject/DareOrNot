/**
 * Created by jumperabg on 15.6.2016 г..
 */

angular.module('starter.constants', [])
  .constant('SERVER_ADDRESS', "http://dareornot.herokuapp.com")
  .constant('SOCKET_CHAT_PORT', '')
  .constant('SERVER_PORT', '')
