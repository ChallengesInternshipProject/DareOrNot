angular.module('starter')
  .service('GoogleService', function ($rootScope, $log, $http) {
    
  });
